import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cafe-dashborad',
  templateUrl: './cafe-dashborad.component.html',
  styleUrls: ['./cafe-dashborad.component.css']
})
export class CafeDashboradComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


}
